/**
 * The Windows ACL runner (@deepseek-ai/dsh-sandbox-windows-acl) depends on
 * `koffi`, a native FFI addon with no Termux prebuilt binary and a source build
 * that needs a CMake toolchain. The package is therefore an OPTIONAL dependency:
 * non-Windows installs may skip it entirely.
 *
 * This loader keeps the require OUT of the module graph so the agent never
 * imports koffi on a platform that cannot install it — the windows-acl chain
 * only ever runs on Windows, so on Android (or any chain-less platform) the
 * loader is never invoked and the missing package is never touched. On a
 * non-Windows host with the package installed it still refuses, because the
 * ACL surface is meaningless outside the Win32 ACL APIs it drives.
 *
 * Extracted into its own module so tests can `vi.mock` it: vi.mock intercepts
 * static imports of local modules, whereas a raw `createRequire` call inside
 * the consumer would load the real package regardless of the mock. The
 * acl-grants suite swaps this for a fake and exercises grant ownership
 * without any native FFI.
 */
type WindowsAclModule = typeof import('@deepseek-ai/dsh-sandbox-windows-acl');
/** Resolve the Windows ACL module on first use, cached for the process lifetime. */
export declare function loadWindowsAcl(): WindowsAclModule;
export {};
//# sourceMappingURL=windows-acl-loader.d.ts.map