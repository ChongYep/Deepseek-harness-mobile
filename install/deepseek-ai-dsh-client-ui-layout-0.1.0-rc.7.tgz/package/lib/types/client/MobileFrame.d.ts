/**
 * Single-column mobile shell, rendered by AppFrame at or below MOBILE_BREAKPOINT.
 * The conversation fills the viewport below a slim control bar; the sidebar and
 * details slots render in always-mounted fixed drawers that slide in over the
 * conversation (side content stays mounted and keeps state — mirroring the
 * desktop never-unmount behavior). Drawer open state reuses the layout store:
 * the sidebar drawer tracks `narrowExpanded` (narrow is forced true here, so
 * `toggleSidebar` flips it — the hamburger semantics) and the details drawer
 * tracks the details width preference (> 0). The shell-overlay slot renders
 * above the control bar but below the drawers.
 */
import type { SessionId } from '@deepseek-ai/dsh-client-runtime/client';
import type { TranslateNS } from '@deepseek-ai/dsh-client-ui-slots';
import type { AppFrameProps } from './AppFrame.tsx';
/** Full composed props: the frame shares the mobile shell needs, plus the
 * viewport width and the current-session signal AppFrame already derived. */
export type MobileFrameProps = {
    useStore: AppFrameProps['useStore'];
    actions: AppFrameProps['actions'];
    renderSlot: AppFrameProps['renderSlot'];
    /** The frame's bound translator (layout namespace, injected by the runtime). */
    t: TranslateNS<'layout'>;
    /** Current-session id (undefined when none is current, or it is blank). */
    detailsSession: SessionId | undefined;
    /** Rendered frame width in px; drawers size off it. */
    viewport: number;
};
/**
 * Render the mobile single-column shell.
 * @param props - frame shares plus the viewport width and the current-session signal.
 * @returns the mobile element tree (top bar, conversation, two drawers, overlay).
 */
export declare function MobileFrame({ useStore, actions, renderSlot, t, detailsSession, viewport, }: MobileFrameProps): import("react").JSX.Element;
//# sourceMappingURL=MobileFrame.d.ts.map