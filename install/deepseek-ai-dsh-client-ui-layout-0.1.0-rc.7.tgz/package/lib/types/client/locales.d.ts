/** `layout` namespace dictionaries: mobile shell controls (top-bar toggles). */
/** Simplified Chinese dictionary (the key-set source of truth). */
export declare const zh: {
    'mobile.openSidebar': string;
    'mobile.openDetails': string;
};
/** The layout namespace key union. */
export type LayoutKey = keyof typeof zh;
/** English dictionary, checked complete against the zh key set. */
export declare const en: {
    'mobile.openSidebar': string;
    'mobile.openDetails': string;
};
//# sourceMappingURL=locales.d.ts.map